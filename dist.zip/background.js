let r = null, o = null, n = Date.now();
const a = (t) => {
  try {
    return new URL(t).hostname;
  } catch {
    return null;
  }
}, l = () => {
  if (o && n) {
    const t = (Date.now() - n) / 1e3;
    chrome.storage.local.get([o], (e) => {
      const c = e[o] || 0;
      chrome.storage.local.set({ [o]: c + t });
    });
  }
  n = Date.now();
};
chrome.tabs.onActivated.addListener((t) => {
  l(), chrome.tabs.get(t.tabId, (e) => {
    r = e.id ?? null, o = a(e.url ?? "");
  });
});
chrome.tabs.onUpdated.addListener((t, e) => {
  t === r && e.url && (l(), o = a(e.url));
});
chrome.windows.onFocusChanged.addListener((t) => {
  t === chrome.windows.WINDOW_ID_NONE ? (l(), o = null) : chrome.tabs.query({ active: !0, windowId: t }, (e) => {
    e[0] && (r = e[0].id ?? null, o = a(e[0].url ?? ""), n = Date.now());
  });
});
