(function(){"use strict";const o=()=>{console.log("content script - sampleFunction() called from another module")};console.log("[CEB] Example content script loaded"),o()})();
